//Isabelle Hoff + Skyla Gyimesi
#include "Game.h"

void Game::loadSettings(){
  //loads the game's settings
}
void Game::loadFloor(int floor){
  //loads the contents of the floor ie monster encounter
}

int Game::gameOver(){
  //ends the game to title returns -1
}

int Game::attackMenu(){
  //user attack interface returns attack attempt value
}

int Game::highScoreSort(){
  //for the title
  //sorts the highscores gotten to reread to player
}